// server.js - simple production-ready Express server with SQLite storage for products
const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();

const PORT = process.env.PORT || 3000;
const app = express();

// static frontend
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json({limit:'5mb'}));

// initialize DB (SQLite file)
const DB_FILE = path.join(__dirname, 'data', 'db.sqlite');
if(!fs.existsSync(path.join(__dirname,'data'))) fs.mkdirSync(path.join(__dirname,'data'));
const db = new sqlite3.Database(DB_FILE);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    title_ar TEXT, title_en TEXT,
    desc_ar TEXT, desc_en TEXT,
    price REAL, image TEXT, category TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password_hash TEXT
  )`);

  // ensure admin user exists with password 'admin' (hashed)
  db.get("SELECT * FROM users WHERE username = ?", ['admin'], (err,row)=>{
    if(err) console.error(err);
    if(!row){
      const pw = 'admin';
      bcrypt.hash(pw, 10, (err,hash)=>{
        if(err) return console.error(err);
        db.run("INSERT INTO users (username, password_hash) VALUES (?,?)", ['admin', hash]);
        console.log('Created default admin user (username: admin, password: admin). Change it after first login.');
      });
    }
  });

  // seed products if empty
  db.get("SELECT COUNT(*) as cnt FROM products", (err,row)=>{
    if(err) console.error(err);
    if(row && row.cnt === 0){
      const sample = [
        {id:'p1', title_ar:'تيشرت كاجوال - أبيض', title_en:'Casual T-Shirt - White', desc_ar:'تيشيرت قطن 100% خامة ممتازة.', desc_en:'100% cotton T-shirt, high quality.', price:250, image:'/icons/sample1.png', category:'ملابس'},
        {id:'p2', title_ar:'سماعات بلوتوث صغيرة', title_en:'Mini Bluetooth Earbuds', desc_ar:'سماعات بجودة صوت جيدة.', desc_en:'Portable earbuds with good sound.', price:420, image:'/icons/sample2.png', category:'إلكترونيات'}
      ];
      const stmt = db.prepare("INSERT INTO products (id,title_ar,title_en,desc_ar,desc_en,price,image,category) VALUES (?,?,?,?,?,?,?,?)");
      sample.forEach(p=> stmt.run(p.id,p.title_ar,p.title_en,p.desc_ar,p.desc_en,p.price,p.image,p.category));
      stmt.finalize();
    }
  });
});

// utility to map db row to product object
function rowToProduct(row){
  return {
    id: row.id,
    title: { ar: row.title_ar, en: row.title_en },
    description: { ar: row.desc_ar, en: row.desc_en },
    price: row.price,
    image: row.image,
    category: row.category
  };
}

// API endpoints
app.get('/api/products', (req,res)=>{
  db.all("SELECT * FROM products", (err, rows)=>{
    if(err) return res.status(500).json({error: 'DB error'});
    res.json({ products: rows.map(rowToProduct) });
  });
});

app.post('/api/products', (req,res)=>{
  const id = 'p' + Date.now();
  const p = req.body;
  db.run("INSERT INTO products (id,title_ar,title_en,desc_ar,desc_en,price,image,category) VALUES (?,?,?,?,?,?,?,?)",
    [id, p.title.ar || '', p.title.en || '', p.description.ar || '', p.description.en || '', p.price || 0, p.image || '/icons/sample1.png', p.category || ''],
    function(err){
      if(err) return res.status(500).json({error:'insert failed'});
      res.json({ ok:true, id });
    });
});

app.put('/api/products/:id', (req,res)=>{
  const id = req.params.id;
  const p = req.body;
  db.run("UPDATE products SET title_ar=?,title_en=?,desc_ar=?,desc_en=?,price=?,image=?,category=? WHERE id=?",
    [p.title.ar || '', p.title.en || '', p.description.ar || '', p.description.en || '', p.price || 0, p.image || '/icons/sample1.png', p.category || '', id],
    function(err){
      if(err) return res.status(500).json({error:'update failed'});
      res.json({ ok:true });
    });
});

app.delete('/api/products/:id', (req,res)=>{
  const id = req.params.id;
  db.run("DELETE FROM products WHERE id = ?", [id], function(err){
    if(err) return res.status(500).json({error:'delete failed'});
    res.json({ ok:true });
  });
});

// import/export endpoints (admin use)
app.post('/api/products/import', (req,res)=>{
  const data = req.body;
  if(!data || !data.products) return res.status(400).json({error:'invalid'});
  const products = data.products;
  const stmt = db.prepare("INSERT OR REPLACE INTO products (id,title_ar,title_en,desc_ar,desc_en,price,image,category) VALUES (?,?,?,?,?,?,?,?)");
  db.serialize(()=>{
    products.forEach(p=>{
      stmt.run(p.id || ('p'+Date.now()), (p.title && p.title.ar) || '', (p.title && p.title.en) || '', (p.description && p.description.ar) || '', (p.description && p.description.en) || '', p.price || 0, p.image || '/icons/sample1.png', p.category || '');
    });
    stmt.finalize(()=> res.json({ok:true}));
  });
});

app.get('/api/products/export', (req,res)=>{
  db.all("SELECT * FROM products", (err, rows)=>{
    if(err) return res.status(500).json({error:'DB error'});
    const products = rows.map(rowToProduct);
    res.setHeader('Content-disposition','attachment; filename=products_export.json');
    res.setHeader('Content-type','application/json');
    res.send(JSON.stringify({products}, null, 2));
  });
});

// basic auth endpoints (for demo only). In production use proper auth (tokens, HTTPS)
app.post('/api/login', (req,res)=>{
  const { username, password } = req.body;
  if(!username || !password) return res.status(400).json({error:'missing'});
  db.get("SELECT * FROM users WHERE username = ?", [username], (err,row)=>{
    if(err) return res.status(500).json({error:'db'});
    if(!row) return res.status(401).json({error:'invalid'});
    bcrypt.compare(password, row.password_hash, (err,match)=>{
      if(err) return res.status(500).json({error:'bcrypt'});
      if(!match) return res.status(401).json({error:'invalid'});
      // simple session token - in prod use JWT or proper sessions
      const token = crypto.randomBytes(16).toString('hex');
      // store token in memory (simple)
      sessions[token] = { user: username, created: Date.now() };
      res.json({ ok:true, token });
    });
  });
});

app.post('/api/logout', (req,res)=>{ res.json({ok:true}); });

// serve SPA (frontend is inside public/)
app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const sessions = {};

app.listen(PORT, ()=> console.log('Server listening on', PORT));
