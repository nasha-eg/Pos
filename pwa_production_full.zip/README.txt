PWA Catalog - Production-ready package
--------------------------------------

What's included:
- public/  -> frontend (PWA) files (index.html, styles.css, app.prod.js, i18n.js, admin.html, icons, manifest, sw.js)
- server.js -> Node.js + Express server using SQLite (data/db.sqlite)
- package.json -> npm dependencies (express, sqlite3, bcrypt)
- Dockerfile, docker-compose.yml
- README provides run & deploy instructions

Quick start (local):
1. Install Node.js (>= 16).
2. In project root run:
   npm install
   node server.js
3. Open http://localhost:3000
4. Default admin user created: username: admin  password: admin  (change immediately)

Important notes:
- This demo stores sessions in-memory and uses a simple login flow. For real production, enable HTTPS and use proper session store or JWT.
- To persist images, host them in /public/icons or use external storage. When you edit products from the admin, changes are saved to SQLite DB.
- To deploy: use Render, DigitalOcean App Platform, Heroku, or Docker on a VPS. The included Dockerfile helps containerize the app.
- To change WhatsApp number: edit public/app.prod.js constant WA_NUMBER.
- To integrate AdMob/AdSense, add the ad scripts to public/index.html and follow platform guidelines (you need HTTPS and domain verification).

If you want, I can also:
- Deploy this to a Render or DigitalOcean droplet and return a live URL (requires your consent and possible cloud credits).
- Replace in-memory session with JWT and add password-change endpoint.
- Add image upload support (requires server-side storage or S3).
