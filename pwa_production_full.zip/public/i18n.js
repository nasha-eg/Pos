// i18n.js - simple translations
window.i18n = (function(){
  const _t = {
    ar: {
      app_title: "كتالوج المنتجات",
      brand_sub: "تطبيق كتالوج بسيط وسهل",
      install: "تثبيت",
      order_btn: "اطلب عبر واتساب",
      ad_placeholder: "مكان إعلان AdMob / AdSense",
      search_placeholder: "ابحث عن منتج أو وصف...",
      all_categories: "كل التصنيفات",
      whatsapp_greet: "مرحبا، أريد أطلب المنتج:",
      load_error: "حدث خطأ في تحميل المنتجات. تأكد من الاتصال بالإنترنت."
    },
    en: {
      app_title: "Product Catalog",
      brand_sub: "Fast simple catalog PWA",
      install: "Install",
      order_btn: "Order via WhatsApp",
      ad_placeholder: "AdMob / AdSense placeholder",
      search_placeholder: "Search product or description...",
      all_categories: "All categories",
      whatsapp_greet: "Hi, I'd like to order:",
      load_error: "Failed to load products. Check your connection."
    }
  };
  let lang = localStorage.getItem('lang') || (navigator.language && navigator.language.startsWith('en') ? 'en' : 'ar');
  return {
    t: (k)=> _t[lang] && _t[lang][k] ? _t[lang][k] : k,
    setLang: (l)=>{ lang = l; localStorage.setItem('lang', l); }
  };
})();