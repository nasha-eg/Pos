// app.prod.js - frontend adapted to call backend API
const WA_NUMBER = "+201000251645";
const tpl = document.getElementById('product-template');
const productsEl = document.getElementById('products');
const searchInput = document.getElementById('search');
const categoryFilter = document.getElementById('categoryFilter');
const langBtn = document.getElementById('langBtn');
const installBtn = document.getElementById('installBtn');

function t(key){ return window.i18n && window.i18n.t ? window.i18n.t(key) : key; }
function applyI18n(){ document.querySelectorAll('[data-i18n]').forEach(el=> el.textContent = t(el.getAttribute('data-i18n')) ); 
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=> el.placeholder = t(el.getAttribute('data-i18n-placeholder')));
}

const DEFAULT_THEME = 'blue';
function applyTheme(theme){
  document.documentElement.setAttribute('data-theme', theme==='blue' ? '' : theme==='dark' ? 'dark' : theme);
  localStorage.setItem('theme', theme);
}
function getTheme(){ return localStorage.getItem('theme') || DEFAULT_THEME; }

function getLang(){ return localStorage.getItem('lang') || (navigator.language && navigator.language.startsWith('en') ? 'en' : 'ar'); }
function setLang(l){ localStorage.setItem('lang', l); window.i18n.setLang(l); applyI18n(); langBtn.textContent = l==='ar' ? 'EN' : 'ع'; document.documentElement.lang = l; document.documentElement.dir = l==='ar' ? 'rtl' : 'ltr'; }

let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); deferredPrompt = e; installBtn.style.display='inline-block'; });
installBtn.addEventListener('click', async ()=>{ if(!deferredPrompt) return; deferredPrompt.prompt(); const choice = await deferredPrompt.userChoice; deferredPrompt=null; installBtn.style.display='none'; });

langBtn.addEventListener('click', ()=> setLang(getLang()==='ar'?'en':'ar'));

async function fetchProducts(){
  try{
    const res = await fetch('/api/products');
    const data = await res.json();
    return data.products || data;
  }catch(e){
    console.error('API fetch failed, trying cached products.json', e);
    const res = await fetch('/products.json');
    const data = await res.json();
    return data.products;
  }
}

async function loadProducts(){
  const list = await fetchProducts();
  buildCategories(list);
  renderProducts(list);
}

function buildCategories(list){
  const cats = ['all', ...Array.from(new Set(list.map(p=>p.category))).filter(Boolean)];
  categoryFilter.innerHTML = '';
  cats.forEach(c=>{
    const opt = document.createElement('option'); opt.value = c; opt.textContent = c==='all' ? t('all_categories') : c; categoryFilter.appendChild(opt);
  });
  categoryFilter.addEventListener('change', renderFiltered);
}

function renderProducts(list){
  productsEl.innerHTML = '';
  list.forEach(p => {
    const node = tpl.content.cloneNode(true);
    const img = node.querySelector('.p-img');
    img.src = p.image || '/icons/sample1.png';
    node.querySelector('.p-title').textContent = getLang()==='ar' ? p.title.ar : p.title.en;
    node.querySelector('.p-desc').textContent = getLang()==='ar' ? p.description.ar : p.description.en;
    node.querySelector('.cat').textContent = p.category || '';
    node.querySelector('.price').textContent = (p.price || 0) + ' ج.م';
    const btn = node.querySelector('.order-btn');
    btn.addEventListener('click', ()=> openWhatsappOrder(p));
    productsEl.appendChild(node);
  });
  applyI18n();
}

function openWhatsappOrder(product){
  const name = getLang()==='ar' ? product.title.ar : product.title.en;
  const currency = getLang()==='ar' ? 'ج.م' : 'EGP';
  const text = `${t('whatsapp_greet')} ${name} - ${product.price} ${currency}`;
  const url = `https://wa.me/${WA_NUMBER.replace('+','')}?text=`+encodeURIComponent(text);
  window.open(url,'_blank');
}

function renderFiltered(){
  const q = searchInput.value.trim().toLowerCase();
  const cat = categoryFilter.value;
  fetchProducts().then(list => {
    let filtered = list;
    if(cat && cat!=='all') filtered = filtered.filter(p=>p.category===cat);
    if(q) filtered = filtered.filter(p => (p.title.ar+p.title.en+p.description.ar+p.description.en).toLowerCase().includes(q));
    renderProducts(filtered);
  });
}

searchInput.addEventListener('input', ()=> renderFiltered());
categoryFilter.addEventListener('change', ()=> renderFiltered());

applyTheme(getTheme());
setLang(getLang());
loadProducts();
