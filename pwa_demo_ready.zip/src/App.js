import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Shop from './pages/Shop';
import Admin from './pages/Admin';

function App() {
  return (
    <Router>
      <nav style={{ padding: 10, background: '#0d6efd', color: '#fff' }}>
        <Link to="/" style={{ margin: 10, color: '#fff' }}>Shop</Link>
        <Link to="/admin" style={{ margin: 10, color: '#fff' }}>Admin</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Shop />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </Router>
  );
}

export default App;
