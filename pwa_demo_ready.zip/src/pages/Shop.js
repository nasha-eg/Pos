import React from 'react';

function Shop() {
  return (
    <div style={{ padding: 20 }}>
      <h2>🛍️ Welcome to Demo Shop</h2>
      <p>Here you can list products (demo mode).</p>
    </div>
  );
}

export default Shop;
