import React, { useState } from 'react';

function Admin() {
  const [theme, setTheme] = useState('blue');

  return (
    <div style={{ padding: 20 }}>
      <h2>⚙️ Admin Panel</h2>
      <p>Change theme:</p>
      <select value={theme} onChange={(e) => setTheme(e.target.value)}>
        <option value="blue">Blue (default)</option>
        <option value="dark">Dark</option>
        <option value="light">Light</option>
      </select>
      <p style={{ marginTop: 20 }}>Selected Theme: {theme}</p>
    </div>
  );
}

export default Admin;
